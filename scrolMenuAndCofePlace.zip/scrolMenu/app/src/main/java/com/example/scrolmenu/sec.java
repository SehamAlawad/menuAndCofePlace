package com.example.scrolmenu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class sec extends AppCompatActivity {


    private String coffeeType;
    private String sweetType;
    private Button mkOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);

    mkOrder = (Button) findViewById(R.id.button2);
    mkOrder.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View v){

            Intent returnIntent = new Intent();

            //add data to intent
            returnIntent.putExtra("coffee_Type", coffeeType);
            returnIntent.putExtra("sweetType", sweetType);

            //set result and go back to main activity (status,intentObject)
            setResult(RESULT_OK,returnIntent);

            finish();
        }

    });
    }

    public void selectCoffee(View view){

        switch (view.getId()){
        case R.id.crmlMachiatoBtn:
            coffeeType = "hot crmlMachiato";
            break;
        case R.id.mochaBtn:
            coffeeType += "hot mocha";
            break;
            case R.id.latteBtn:
                coffeeType += "hot latte";
                break;
            case R.id.esprsoBtn:
                coffeeType += "hot espresso";
                break;
            case R.id.CappuccinoBtn:
                coffeeType += "hot Cappuccino";
                break;
            case R.id.amrcanoBtn:
                coffeeType += "hot amricano";
                break;
            case R.id.frenchBtn:
                coffeeType += "ICED FRENCH VANILLA";
                break;
            case R.id.chocoMochaBtn:
                coffeeType += "ICED CHOCOLATE MOCHA";
                break;
            case R.id.spanishBtn:
                coffeeType += "ICED SPANISH LATTE";
                break;
            case R.id.icedCrmlMacchiatoBtn:
                coffeeType += "ICED Caramel Macchiato";

    } }

    public void selectSweets(View v){

        switch (v.getId()){
            case R.id.browniBtn:
                sweetType = "BROWNIES";
                break;
            case R.id.MacaroonsBtn:
                sweetType += "MACAROONS";
                break;
            case R.id.CookiesBtn:
                sweetType += "COOKIES";
                break;
            case R.id.CupcakesBtn:
                sweetType += "CUPCAKES";

        } }
}

